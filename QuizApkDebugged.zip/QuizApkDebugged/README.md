# QuizApp
Phone application that is a Quiz.  Technologies used: PhoneGap, HTML, CSS, JavaScript, JQuery Mobile
