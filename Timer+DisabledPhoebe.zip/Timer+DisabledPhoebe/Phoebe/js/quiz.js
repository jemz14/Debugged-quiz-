var score = 0;
var scoreChem = 0;
var scoreKen = 0;
var scoreThan = 0;
var scoreRufo =0;
var scoreGabrillo =0;


/*Synonyms*/


function myFunction() {
    // Declare variables
    var input, filter, ul, li, a, i;
    input = document.getElementById('chemWords');
    filter = input.value.toUpperCase();
    ul = document.getElementById("WordList");
    li = ul.getElementsByTagName('li');

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}

/*Easy*/
	var jemz = [
		{
			'question': "What event is Harriet Tubman mostly linked with?",
			'choices': ["Native American rights", "Underground Railroad", "Shay's Rebellion", "Civil War"],
			'correctChoice': "Underground Railroad",
			flag: 0
		},
		{
			'question': "Where was Jamestown established?",
			'choices': ["New Hampshire", "Delaware", "Maryland", "Virginia", "South Carolina"],
			'correctChoice': "Virginia",
			flag: 0
		},
		{
			'question': "What year did the U.S. annex Hawaii?",
			'choices': ["1870","1886","1898", "1879"],
			'correctChoice': "1898",
			flag: 0
		},
		{
			'question': "Which Court Case paved the way for the Jim Crow laws in the South?",
			'choices': ["Plessy v. Ferguson", "Engel v. Vitale", "Marbury v. Madison", "McCulloch v. Maryland"],
			'correctChoice': "Plessy v. Ferguson",
			flag: 0
		},

		{
			'question': "What year did the American Revolution begin?",
			'choices': ["1773", "1774", "1775", "1776"],
			'correctChoice': "1775",
			flag: 0
		},
		{
			'question': "Which nation won the French and Indian War (also known as the Seven Year's War)?",
			'choices': ["Britain", "France", "Neither side won"],
			'correctChoice': "Britain",
			flag: 0
		},
		{
			'question': "Which of the following presidents was impeached by the House of Representatives? ",
			'choices': ["William Harrison", "Andrew Johnson", "Ulysses Grant", "James Buchanan"],
			'correctChoice': "Andrew Johnson",
			flag: 0
		},

		{
			'question': "When did the Mexican-American War take place?",
			'choices': ["1826", "1846", "1849", "1834", "1853"],
			'correctChoice': "1846",
			flag: 0
		},

		{
			'question': "Who was the second president of the United States and what year did he begin his term? ",
			'choices': ["Thomas Jefferson, 1797", "Thomas Jefferson, 1793", "John Adams, 1797", "John Adams, 1793"],
			'correctChoice': "John Adams, 1797",
			flag: 0
		},
		{
			'question': "Which was the first state to secede from the Union in 1861?",
			'choices': ["Mississippi", "North Carolina", "Alabama", "South Carolina"],
			'correctChoice': "South Carolina",
			flag: 0
		},
		]


/*Medium*/
	var chem = [
		{
			'question': "When did the US enter World War I?",
			'choices': ["1914", "1917", "1920", "1921"],
			'correctChoice': "1917",
			flag: 0
		},
		{
			'question': "When does Japan Attack Pearl Harbor?",
			'choices': ["December 17,1940", "November 7, 1941", "December 7, 1941", "December 7, 1939", "December 15, 1941"],
			'correctChoice': "December 7, 1941",
			flag: 0
		},
		{
			'question': "Which president signed the Voting Rights Act of 1965, guaranteeing African Americans the right to vote?",
			'choices': ["Dwight D. Eisenhower","Grover Cleveland","Lyndon Johnson", "Richard Nixon"],
			'correctChoice': "Lyndon Johnson",
			flag: 0
		},
		{
			'question': "What year did the San Francisco earthquake happen, which killed over 500 people?",
			'choices': ["1915", "1970", "1900", "1906"],
			'correctChoice': "1906",
			flag: 0
		},

		{
			'question': "What year did the US join Vietnam War?",
			'choices': ["1955", "1965", "1980", "1976"],
			'correctChoice': "1965",
			flag: 0
		},
		{
			'question': "What year did Puerto Rico become part of the US?",
			'choices': ["1952", "1959", "1930","1960"],
			'correctChoice': "1952",
			flag: 0
		},
		{
			'question': "What year did Martin Luther King Jr. deliver his 'I Have A Dream' speech?",
			'choices': ["1971", "1963", "1960", "1969"],
			'correctChoice': "1963",
			flag: 0
		},

		{
			'question': "The 'Bay of Pigs' American invasion occured in which nation?",
			'choices': ["Mexico", "El Salvador", "Panama", "Cuba", "Costa Rica"],
			'correctChoice': "Cuba",
			flag: 0
		},

		{
			'question': "What year was President Barack Obama elected president of the US?",
			'choices': ["2007", "2006", "2008", "2009"],
			'correctChoice': "2008",
			flag: 0
		},
		{
			'question': "How many people are estimated to have died in the 9/11 terrorist attack on the US?",
			'choices': ["around 2000 people", "around 3000 people", " around 1500 people", "over 5000 people"],
			'correctChoice': "around 3000 people",
			flag: 0
		},
		]


/*Hard*/
	var rufo = [
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		]


/*Antonyms*/


/*Easy*/
	var ken = [
		{
			'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
			'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
			'correctChoice': "She spelled 'computer' wrong",
			flag: 0
		},
		{
			'question': "On boy meets world, what is the crazy older brother's name?",
			'choices': ["Henry", "Patrick", "James", "Eric", "Daniel"],
			'correctChoice': "Henry",
			flag: 0
		},
		{
			'question': "Who was DJ's best friend's name on 'Full House'",
			'choices': ["Jessica","Kylie","Stephanie", "Kimmy"],
			'correctChoice': "Kimmy",
			flag: 0
		},
		{
			'question': "In 'Saved by the Bell', what were Zack and Kelly dressed up as the night they broke up?",
			'choices': ["monkeys", "Romeo and Juliet", "clowns", "Adam and Eve"],
			'correctChoice': "Romeo and Juliet",
			flag: 0
		},

		{
			'question': "In Growing Pains, What was boners dad's name?",
			'choices': ["Jefferson", "Robert", "Sylvester", "Edward"],
			'correctChoice': "Sylvester",
			flag: 0
		},
		{
			'question': "On an episode of 'Friends', what did Jean-Claude Van Damme boast he could do?",
			'choices': ["crush a walnut with his butt", "take cap off bottle with his eye", "touch his nose with his tongue"],
			'correctChoice': "crush a walnut with his butt",
			flag: 0
		},
		{
			'question': "In Fresh Prince of Bel-Air what was the butlers name?",
			'choices': ["Phil", "Geoffrey", "Grant", "George"],
			'correctChoice': "Geoffrey",
			flag: 0
		},

		{
			'question': "How did Danny Tanner's wife die on 'Full House'?",
			'choices': ["cancer", "car crash", "drug overdose", "unknown circumstances"],
			'correctChoice': "car crash",
			flag: 0
		},

		{
			'question': "Which of the following was Chandler's girlfriend at some point in 'Friends'?",
			'choices': ["Jannette", "Julia", "Janice", "Jasmine"],
			'correctChoice': "Janice",
			flag: 0
		},
		{
			'question': "On Saved By The Bell, what was the name of the beach club that the gang worked at?",
			'choices': ["Malibu Sands Beach Club", "Venice Beach club", "Aloha Beach Club", "none of the above"],
			'correctChoice': "Malibu Sands Beach Club",
			flag: 0
		},
		]


/*Medium*/
	var than = [
		{
			'question': "Who did Arnold live with on 'Hey Arnold'?",
			'choices': ["parents", "aunt and uncle", "grandparents"],
			'correctChoice': "grandparents",
			flag: 0
		},
		{
			'question': "How did Tommy's family know Angelica's family in 'Rugrats'?",
			'choices': ["neighbors", "family friends", "relatives"],
			'correctChoice': "relatives",
			flag: 0
		},
		{
			'question': "True or False: In 'Rocko's Modern Life', Rocko was a Kangaroo.",
			'choices': ["True","False"],
			'correctChoice': "False",
			flag: 0
		},
		{
			'question': "What was the name of Arnold's best friend in 'Hey Arnold'?",
			'choices': ["Eugene", "Alfred", "Gerald", "Doug"],
			'correctChoice': "Gerald",
			flag: 0
		},

		{
			'question': "What is the name of Dexter's annoying sister in 'Dexter's Laboratory'?",
			'choices': ["Jesse", "Deedee", "Meemee", "Lili"],
			'correctChoice': "Deedee",
			flag: 0
		},
		{
			'question': "In 'Doug', what was the name of Doug's dog?",
			'choices': ["Porkchop", "Peppers", "Max"],
			'correctChoice': "Porkchop",
			flag: 0
		},
		{
			'question': "In 'Courage The Cowardly Dog', what was the setting of the show?",
			'choices': ["Middle of Nowhere", "city", "small town", "Suburbs"],
			'correctChoice': "Middle of Nowhere",
			flag: 0
		},

		{
			'question': "What is the name of Tommy's little brother in 'Rugrats'?",
			'choices': ["Patric", "Chucky", "Phil", "Dil"],
			'correctChoice': "Dil",
			flag: 0
		},

		{
			'question': "What was the name of Arnold's secret admirer in 'Hey Arnold'?",
			'choices': ["Helga", "Julia", "Hagen", "Olga"],
			'correctChoice': "Helga",
			flag: 0
		},
		{
			'question': "What is the name CatDog's mouse friend in 'CatDog'?",
			'choices': ["Albert", "Teddy", "Winslow", "Wilbur"],
			'correctChoice': "Winslow",
			flag: 0
		},
		]

/*Hard*/
	var gabrillo = [
		{
			'question': "Who did Arnold live with on 'Hey Arnold'?",
			'choices': ["parents", "aunt and uncle", "grandparents"],
			'correctChoice': "grandparents",
			flag: 0
		},
		{
			'question': "How did Tommy's family know Angelica's family in 'Rugrats'?",
			'choices': ["neighbors", "family friends", "relatives"],
			'correctChoice': "relatives",
			flag: 0
		},
		{
			'question': "True or False: In 'Rocko's Modern Life', Rocko was a Kangaroo.",
			'choices': ["True","False"],
			'correctChoice': "False",
			flag: 0
		},
		{
			'question': "What was the name of Arnold's best friend in 'Hey Arnold'?",
			'choices': ["Eugene", "Alfred", "Gerald", "Doug"],
			'correctChoice': "Gerald",
			flag: 0
		},

		{
			'question': "What is the name of Dexter's annoying sister in 'Dexter's Laboratory'?",
			'choices': ["Jesse", "Deedee", "Meemee", "Lili"],
			'correctChoice': "Deedee",
			flag: 0
		},
		{
			'question': "In 'Doug', what was the name of Doug's dog?",
			'choices': ["Porkchop", "Peppers", "Max"],
			'correctChoice': "Porkchop",
			flag: 0
		},
		{
			'question': "In 'Courage The Cowardly Dog', what was the setting of the show?",
			'choices': ["Middle of Nowhere", "city", "small town", "Suburbs"],
			'correctChoice': "Middle of Nowhere",
			flag: 0
		},

		{
			'question': "What is the name of Tommy's little brother in 'Rugrats'?",
			'choices': ["Patric", "Chucky", "Phil", "Dil"],
			'correctChoice': "Dil",
			flag: 0
		},

		{
			'question': "What was the name of Arnold's secret admirer in 'Hey Arnold'?",
			'choices': ["Helga", "Julia", "Hagen", "Olga"],
			'correctChoice': "Helga",
			flag: 0
		},
		{
			'question': "What is the name CatDog's mouse friend in 'CatDog'?",
			'choices': ["Albert", "Teddy", "Winslow", "Wilbur"],
			'correctChoice': "Winslow",
			flag: 0
		},
		]


function randomize(category){
	var checkAsked = 0;
	for(var i=0; i<category.length; i++)
	{
		if(category[i].flag == 1)
			checkAsked++;
	}

	if(checkAsked == 10)
	{
		return -1;
	}
	else{
		var r = Math.floor(Math.random() * 10);
		while(category[r].flag == 1)
		{
			r = Math.floor(Math.random() * 10);
		}
		category[r].flag = 1;
		return r;
	}
}

function refresh() {
    window.location.replace("#mainPage");
    $(document).on("pagebeforeshow","#mainPage", function() {
        window.location.reload();
    });
}

var count;
function showJemz() {
    for(var i=0; i<jemz.length; i++)
        jemz[i].flag = 0;
    $(document).ready(function showJemzQuestions(){
        $('#jemzStartPage').hide();
        $('#qa').show();
        count = randomize(jemz);
        if (count == -1)
        {
            $('#qa').hide();
            $('#nextStop').hide();
            $('#result').show();
            $('#score2').html(score);
            $('#playAgain').show();
            $('#return').show();
            $('#playAgain').click(function(){
                $('#return').hide();
                $('#result').hide();
                $('#playAgainJemz').hide();
                score=0;
                showJemz();
            });
            $('#return').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qa");
       
        removeExistingQuestion(whereToAdd, "jemz_choices");
    
        var q = document.createElement("h4");
        q.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(jemz[count].question);
        q.appendChild(txt);
        whereToAdd.appendChild(q);
        $('#score').html(score);
        $('#score2').html(score);
    

        var ulist = document.createElement("ul");
        ulist.setAttribute('id','jemz_choices');

        for (var i = 0; i < jemz[count].choices.length; ++i){

            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','jemz');
            choice.setAttribute('value',jemz[count].choices[i]);
        
            ulist.appendChild(choice);
        
            var jemzLabel = document.createElement("label");
            jemzLabel.htmlFor = choice.id;
            jemzLabel.appendChild(choice);
            var jemzNameTextNode = document.createTextNode(jemz[count].choices[i]);
            jemzLabel.appendChild(jemzNameTextNode);
        
            ulist.appendChild(jemzLabel);

        }

        whereToAdd.appendChild(ulist);
        $('#nextStop').show();
        $('#next').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('jemz');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == jemz[count].correctChoice)
                            {
                                score += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showJemzQuestions();
            }
           
        });
        $('#stop').click(function(){
            $('#qa').hide();
            $('#nextStop').hide();
            $('#result').show();
            $('#score2').html(score);
            $('#playAgain').show();
            $('#return').show();
            $('#playAgain').click(function(){
                $('#return').hide();
                $('#result').hide();
                $('#playAgainJemz').hide();
                score=0;
                showJemz();
            });
                         
            $('#return').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });

            });

        });
           
    });
}



function showChem() {
    for(var i=0; i<chem.length; i++)
        chem[i].flag = 0;
    $(document).ready(function showChemQuestions(){
        $('#chemStartPage').hide();
        $('#qaChem').show();
        count = randomize(chem);
        if (count == -1)
        {
            $('#qaChem').hide();
            $('#nextStopChem').hide();
            $('#resultChem').show();
            $('#score2Chem').html(scoreChem);
            $('#playAgainChem').show();
            $('#returnChem').show();
            $('#playAgainChem').click(function(){
                $('#returnChem').hide();
                $('#resultChem').hide();
                $('#playAgainChem').hide();
                scoreChem=0;
                showChem();
            });
            $('#returnChem').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qaChem");

        removeExistingQuestion(whereToAdd, "chem_choices");
    
        var qChem = document.createElement("h4");
        qChem.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(chem[count].question);
        qChem.appendChild(txt);
        whereToAdd.appendChild(qChem);
        $('#scoreChem').html(scoreChem);
        $('#score2Chem').html(scoreChem);
    

        var ulist = document.createElement("ul");
        ulist.setAttribute('id','chem_choices');

        for (var i = 0; i < chem[count].choices.length; ++i){

            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','chem');
            choice.setAttribute('value',chem[count].choices[i]);
        
            ulist.appendChild(choice);
        
            var chemLabel = document.createElement("label");
            chemLabel.htmlFor = choice.id;
            chemLabel.appendChild(choice);
            var chemNameTextNode = document.createTextNode(chem[count].choices[i]);
            chemLabel.appendChild(chemNameTextNode);

            ulist.appendChild(chemLabel);

        }

        whereToAdd.appendChild(ulist);
        $('#nextStopChem').show();
        $('#nextChem').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('chem');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == chem[count].correctChoice)
                            {
                                scoreChem += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showChemQuestions();
            }
           
        });
        $('#stopChem').click(function(){
            $('#qaChem').hide();
            $('#nextStopChem').hide();
            $('#resultChem').show();
            $('#score2Chem').html(scoreChem);
            $('#playAgainChem').show();
            $('#returnChem').show();
            $('#playAgainChem').click(function(){
                $('#returnChem').hide();
                $('#resultChem').hide();
                $('#playAgainChem').hide();
                scoreChem=0;
                showChem();
            });
            $('#returnChem').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}





function showRufo() {
    for(var i=0; i<rufo.length; i++)
        rufo[i].flag = 0;
    $(document).ready(function showRufoQuestions(){
        $('#rufoStartPage').hide();
        $('#qaRufo').show();
        count = randomize(rufo);
        if (count == -1)
        {
            $('#qaRufo').hide();
            $('#nextStopRufo').hide();
            $('#resultRufo').show();
            $('#score2Rufo').html(scoreRufo);
            $('#playAgainRufo').show();
            $('#returnRufo').show();
            $('#playAgainRufo').click(function(){
                $('#returnRufo').hide();
                $('#resultRufo').hide();
                $('#playAgainRufo').hide();
                scoreRufo=0;
                showRufo();
            });
            $('#returnRufo').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qaRufo");

        removeExistingQuestion(whereToAdd, "rufo_choices");
    
        var qRufo = document.createElement("h4");
        qRufo.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(rufo[count].question);
        qRufo.appendChild(txt);
        whereToAdd.appendChild(qRufo);
        $('#scoreRufo').html(scoreRufo);
        $('#score2Rufo').html(scoreRufo);
    

        var ulist = document.createElement("ul");
        ulist.setAttribute('id','rufo_choices');

        for (var i = 0; i < rufo[count].choices.length; ++i){

            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','rufo');
            choice.setAttribute('value',rufo[count].choices[i]);
        
            ulist.appendChild(choice);
        
            var rufoLabel = document.createElement("label");
            rufoLabel.htmlFor = choice.id;
            rufoLabel.appendChild(choice);
            var rufoNameTextNode = document.createTextNode(rufo[count].choices[i]);
            rufoLabel.appendChild(rufoNameTextNode);

            ulist.appendChild(rufoLabel);

        }

        whereToAdd.appendChild(ulist);
        $('#nextStopRufo').show();
        $('#nextRufo').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('rufo');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == rufo[count].correctChoice)
                            {
                                scoreRufo += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showRufoQuestions();
            }
           
        });
        $('#stopRufo').click(function(){
            $('#qaRufo').hide();
            $('#nextStopRufo').hide();
            $('#resultRufo').show();
            $('#score2Rufo').html(scoreRufo);
            $('#playAgainRufo').show();
            $('#returnRufo').show();
            $('#playAgainRufo').click(function(){
                $('#returnRufo').hide();
                $('#resultRufo').hide();
                $('#playAgainRufo').hide();
                scoreRufo=0;
                showRufo();
            });
            $('#returnRufo').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}






function showThan() {
    for(var i=0; i<than.length; i++)
        than[i].flag = 0;
    $(document).ready(function showThanQuestions(){
        $('#thanStartPage').hide();
        $('#qaThan').show();
        count = randomize(than);
        if (count == -1)
        {
            $('#qaThan').hide();
            $('#nextStopThan').hide();
            $('#resultThan').show();
            $('#score2Than').html(scoreThan);
            $('#playAgainThan').show();
            $('#returnThan').show();
            $('#playAgainThan').click(function(){
                $('#returnThan').hide();
                $('#resultThan').hide();
                $('#playAgainThan').hide();
                scoreThan=0;
                showThan();
            });
            $('#returnThan').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });

            });
        }
        var whereToAdd = document.getElementById("qaThan");

        removeExistingQuestion(whereToAdd, "than_choices");
    
        var qThan = document.createElement("h4");
        qThan.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(than[count].question);
        qThan.appendChild(txt);
        whereToAdd.appendChild(qThan);
        $('#scoreThan').html(scoreThan);
        $('#score2Than').html(scoreThan);
    

        var ulist = document.createElement("ul");
        ulist.setAttribute('id','than_choices');

        for (var i = 0; i < than[count].choices.length; ++i){

            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','than');
            choice.setAttribute('value',than[count].choices[i]);
        
 
            ulist.appendChild(choice);
        
  
            var thanLabel = document.createElement("label");
            thanLabel.htmlFor = choice.id;
            thanLabel.appendChild(choice);
            var thanNameTextNode = document.createTextNode(than[count].choices[i]);
            thanLabel.appendChild(thanNameTextNode);
        
            ulist.appendChild(thanLabel);

        }

        whereToAdd.appendChild(ulist);
        $('#nextStopThan').show();
        $('#nextThan').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('than');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == than[count].correctChoice)
                            {
                                scoreThan += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showThanQuestions();
            }
           
        });
        $('#stopThan').click(function(){
            $('#qaThan').hide();
            $('#nextStopThan').hide();
            $('#resultThan').show();
            $('#score2Than').html(scoreShows);
            $('#playAgainThan').show();
            $('#returnThan').show();
            $('#playAgainThan').click(function(){
                $('#returnThan').hide();
                $('#resultThan').hide();
                $('#playAgainThan').hide();
                scoreThan=0;
                showThan();
            });
            $('#returnThan').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}





function showKen() {
    for(var i=0; i<ken.length; i++)
        ken[i].flag = 0;
    $(document).ready(function showKenQuestions(){
        $('#kenStartPage').hide();
        $('#qaKen').show();
        count = randomize(ken);
        if (count == -1)
        {
            $('#qaKen').hide();
            $('#nextStopKen').hide();
            $('#resultKen').show();
            $('#score2Ken').html(scoreKen);
            $('#playAgainKen').show();
            $('#returnKen').show();
            $('#playAgainKen').click(function(){
                $('#returnKen').hide();
                $('#resultKen').hide();
                $('#playAgainKen').hide();
                scoreKen=0;
                showKen();
            });
            $('#returnKen').click( function(){
               window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });

            });
        }
        var whereToAdd = document.getElementById("qaKen");

        removeExistingQuestion(whereToAdd, "ken_choices");
    
        var qKen = document.createElement("h4");
        qKen.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(ken[count].question);
        qKen.appendChild(txt);
        whereToAdd.appendChild(qKen);
        $('#scoreKen').html(scoreKen);
        $('#score2Ken').html(scoreKen);
    
 
        var ulist = document.createElement("ul");
        ulist.setAttribute('id','ken_choices');

        for (var i = 0; i < ken[count].choices.length; ++i){

            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','ken');
            choice.setAttribute('value',ken[count].choices[i]);
        
            ulist.appendChild(choice);
        
            var kenLabel = document.createElement("label");
            kenLabel.htmlFor = choice.id;
            kenLabel.appendChild(choice);
            var kenNameTextNode = document.createTextNode(ken[count].choices[i]);
            kenLabel.appendChild(kenNameTextNode);

            ulist.appendChild(kenLabel);

        }
        whereToAdd.appendChild(ulist);
        $('#nextStopKen').show();
        $('#nextKen').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('ken');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == ken[count].correctChoice)
                            {
                                scoreKen += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showKenQuestions();
            }
           
        });
        $('#stopKen').click(function(){
            $('#qaKen').hide();
            $('#nextStopKen').hide();
            $('#resultKen').show();
            $('#score2Ken').html(scoreKen);
            $('#playAgainKen').show();
            $('#returnKen').show();
            $('#playAgainKen').click(function(){
                $('#returnKen').hide();
                $('#resultKen').hide();
                $('#playAgainKen').hide();
                scoreKen=0;
                showKen();
            });
            $('#returnKen').click(function(){
               window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}



function showGabrillo() {
    for(var i=0; i<gabrillo.length; i++)
        gabrillo[i].flag = 0;
    $(document).ready(function showGabrilloQuestions(){
        $('#gabrilloStartPage').hide();
        $('#qaGabrillo').show();
        count = randomize(gabrillo);
        if (count == -1)
        {
            $('#qaGabrillo').hide();
            $('#nextStopGabrillo').hide();
            $('#resultGabrillo').show();
            $('#score2Gabrillo').html(scoreGabrillo);
            $('#playAgainGabrillo').show();
            $('#returnGabrillo').show();
            $('#playAgainGabrillo').click(function(){
                $('#returnGabrillo').hide();
                $('#resultGabrillo').hide();
                $('#playAgainGabrillo').hide();
                scoreGabrillo=0;
                showGabrillo();
            });
            $('#returnGabrillo').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qaGabrillo");

        removeExistingQuestion(whereToAdd, "gabrillo_choices");
    
        var qGabrillo = document.createElement("h4");
        qGabrillo.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(gabrillo[count].question);
        qGabrillo.appendChild(txt);
        whereToAdd.appendChild(qGabrillo);
        $('#scoreGabrillo').html(scoreGabrillo);
        $('#score2Gabrillo').html(scoreGabrillo);
    

        var ulist = document.createElement("ul");
        ulist.setAttribute('id','gabrillo_choices');

        for (var i = 0; i < gabrillo[count].choices.length; ++i){

            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','gabrillo');
            choice.setAttribute('value',gabrillo[count].choices[i]);
        
            ulist.appendChild(choice);
        
            var gabrilloLabel = document.createElement("label");
            gabrilloLabel.htmlFor = choice.id;
            gabrilloLabel.appendChild(choice);
            var gabrilloNameTextNode = document.createTextNode(gabrillo[count].choices[i]);
            gabrilloLabel.appendChild(gabrilloNameTextNode);

            ulist.appendChild(gabrilloLabel);

        }

        whereToAdd.appendChild(ulist);
        $('#nextStopGabrillo').show();
        $('#nextGabrillo').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('gabrillo');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == gabrillo[count].correctChoice)
                            {
                                scoreGabrillo += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showGabrilloQuestions();
            }
           
        });
        $('#stopGabrillo').click(function(){
            $('#qaGarbrillo').hide();
            $('#nextStopGabrillo').hide();
            $('#resultGabrillo').show();
            $('#score2Gabrillo').html(scoreGabrillo);
            $('#playAgainGabrillo').show();
            $('#returnGabrillo').show();
            $('#playAgainGarbrillo').click(function(){
                $('#returnGabrillo').hide();
                $('#resultGabrillo').hide();
                $('#playAgainGabrillo').hide();
                scoreGabrillo=0;
                showGabrillo();
            });
            $('#returnGabrillo').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}



function removeExistingQuestion(parent, nameChoices){
    var elem = document.getElementById(nameChoices);
    var elem2 = document.getElementById("inquiry");
    if (elem != null)
        parent.removeChild(elem);
    if(elem2 != null)
        parent.removeChild(elem2);
}

function registerHandlers(){
	document.getElementById("startJemz").onclick = showJemz;
	document.getElementById("startKen").onclick = showKen;
	document.getElementById("startChem").onclick = showChem;
	document.getElementById("startRufo").onclick = showRufo;
    document.getElementById("startThan").onclick = showThan;
    document.getElementById("startGabrillo").onclick = showGabrillo;
    //document.getElementById("home").onclick = refresh;
    
}
var total_seconds = 60*5;
var c_minutes = parseInt(total_seconds/60);
var c_seconds = parseInt(total_seconds%60);

function CheckTime(){
document.getElementById("quiz-time-left1").innerHTML
= 'Time Left: ' + c_minutes + ' minutes ' + c_seconds + ' seconds ' ;

if(total_seconds <=0){
setTimeout('nextQuiz()',1);
} else {
total_seconds = total_seconds -1;
c_minutes = parseInt(total_seconds/60);
c_seconds = parseInt(total_seconds%60);
setTimeout("CheckTime()",1000);
}}
setTimeout("CheckTime()",1000);

function enableButton2() {
            document.getElementById("startChem").disabled = false;
        }
function enableButton3() {
            document.getElementById("startRufo").disabled = false;
        }
function enableButton4() {
            document.getElementById("startThan").disabled = false;
        }
function enableButton5() {
            document.getElementById("startGabrillo").disabled = false;
        }